public class Main {
    public static void main(String[] args) {
        Gato dory = new Gato("SRD", "Dory", 5, "Cinza");
        
        Tutor tu = new Tutor("leandro", null);
    }
}
